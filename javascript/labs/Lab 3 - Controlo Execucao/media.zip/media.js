window.addEventListener('load', function() {
    const goBtn = document.getElementById('go');
    goBtn.addEventListener('click', showAverage);
});

function showAverage() {
    const numbersString = document.getElementById('numbers').value.trim();
    const values = numbersString.split(/\s+/);

    // COMPLETAR A PARTIR DAQUI


}
